-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 25, 2023 at 10:48 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `anybooks`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `genre` varchar(255) NOT NULL,
  `price` int(100) NOT NULL,
  `quantity` int(100) NOT NULL,
  `image` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `user_id`, `name`, `genre`, `price`, `quantity`, `image`) VALUES
(19, 2, 'Solo Leveling', 'Manga', 230, 1, 'sl1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `number` int(12) NOT NULL,
  `message` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `user_id`, `name`, `email`, `number`, `message`) VALUES
(1, 2, 'User1', 'user1@gmail.com', 2147483647, 'Trial Feedback One !!');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `number` varchar(12) NOT NULL,
  `email` varchar(100) NOT NULL,
  `method` varchar(50) NOT NULL,
  `address` varchar(500) NOT NULL,
  `total_products` varchar(1000) NOT NULL,
  `total_price` int(100) NOT NULL,
  `placed_on` varchar(50) NOT NULL,
  `payment_status` varchar(20) NOT NULL DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `name`, `number`, `email`, `method`, `address`, `total_products`, `total_price`, `placed_on`, `payment_status`) VALUES
(2, 2, 'User1', '9734865210', 'user1@gmail.com', 'cash on delivery', 'flat no. 1st Street, Some Area, Japan - ', ', Solo Leveling (1) , TBATE : Early Years (v1) (1) ', 570, '15-Sep-2023', 'Pending'),
(3, 2, 'User1', '1122334455', 'user1@gmail.com', 'credit card', 'Bldg 1, Street1, Country1 - ', ', To Kill a MockingBird (1) , Nightshade (1) ', 380, '22-Sep-2023', 'Completed');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `genre` varchar(255) NOT NULL,
  `price` int(100) NOT NULL,
  `image` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `genre`, `price`, `image`) VALUES
(6, 'Hamlet', 'Novel', 270, 'book4.jpeg'),
(7, 'Macbeth', 'Novel', 250, 'book5.jpg'),
(8, 'Oliver Twist', 'Novel', 280, 'book6.jpg'),
(9, 'Sherlock Holmes (V1)', 'Novel', 300, 'book8.jpg'),
(10, 'Sherlock Holmes (V2)', 'Novel', 300, 'book9.jpg'),
(11, 'Sherlock Holmes (V3)', 'Novel', 300, 'book10.jpg'),
(12, 'Sherlock Holmes (V4)', 'Novel', 300, 'book11.jpg'),
(13, 'Harry Potter & The Cursed Child', 'Novel', 190, 'hp1.jpg'),
(14, 'Harry Potter & Goblet of Fire', 'Novel', 180, 'hp2.jpg'),
(15, 'Harry Potter & Chamber the of Secrets', 'Novel', 180, 'hp3.png'),
(16, 'Harry Potter & the Order of Phoenix', 'Novel', 190, 'hp5.jpg'),
(17, 'Einstein', 'Autobiography', 220, 'in8.jpg'),
(18, 'Stephen Hawking', 'Autobiography', 220, 'in9.jpg'),
(19, 'Steve Jobs', 'Autobiography', 230, 'in2.jpg'),
(20, 'Elon Musk', 'Autobiography', 240, 'in16.jpg'),
(21, 'Nikola Tesla', 'Autobiography', 220, 'in15.jpg'),
(22, 'I know why the Caged Bird sings', 'Psychological', 180, 'book1.jpeg'),
(23, 'GooseBumps', 'Novel', 150, 'book2.jpeg'),
(24, 'The Power Of Your Subconcious Mind', 'Psychological', 200, 'book3.jpg'),
(25, 'Man\'s Search for Meaning', 'Psychological', 170, 'in3.jpg'),
(26, 'To Kill a MockingBird', 'Psychological', 220, 'in7.jpg'),
(27, 'Fooled by Randomness', 'Psychological', 180, 'in14.jpg'),
(28, 'The Black Swan', 'Psychological', 170, 'in17.jpg'),
(29, 'The Third Door', 'Psychological', 170, 'in18.jpg'),
(30, 'C++', 'Educational', 200, 'cplusplus.jpg'),
(31, 'C#', 'Educational', 200, 'csharp.jpg'),
(32, 'Java', 'Educational', 170, 'java.jpg'),
(33, 'Python', 'Educational', 190, 'python.jpeg'),
(34, 'Operating Systems', 'Educational', 190, 'os.jpg'),
(35, 'Blink', 'Psychological', 150, 'in19.jpg'),
(36, 'Freefall', 'Psychological', 160, 'bestseller3.jpg'),
(37, 'Nightshade', 'Psychological', 160, 'bestseller2.jpg'),
(38, 'Solo Leveling', 'Manga', 230, 'sl1.jpg'),
(40, 'Omniscient Reader\'s Viewpoint', 'Manga', 240, 'orv1.jpg'),
(41, 'TBATE : Early Years (v1)', 'Manga', 340, 'tbate1.jpg'),
(42, 'TBATE : New Heights (v2)', 'Manga', 340, 'tbate2.jpg'),
(43, 'TBATE : Beckoning Fates (v3)', 'Manga', 340, 'tbate3.jpg'),
(44, 'TBATE : Horizon\'s Edge (v4)', 'Manga', 340, 'tbate4.jpg'),
(47, 'TBATE : Divergence (v7)', 'Manga', 340, 'tbate7.jpg'),
(48, 'TBATE : Ascension (v8)', 'Manga', 340, 'tbate81.jpg'),
(49, 'TBATE : Amongst The Fallen (v8.5)', 'Manga', 340, 'tbate83.jpg'),
(51, 'TBATE : Retribution (v10)', 'Manga', 340, 'tbate10.jpg'),
(52, 'TBATE : Different Path (v10.5)', 'Manga', 340, 'tbate101.jpg'),
(53, 'TBATE : Reckoning (v9)', 'Manga', 340, 'tbate82.jpg'),
(54, 'TBATE : Convergence (v5)', 'Manga', 340, 'tbate5.jpg'),
(55, 'TBATE : Transcendence (v6)', 'Manga', 340, 'tbate6.jpg'),
(56, 'Attack On Titan', 'Manga', 160, 'aot1.jpeg'),
(57, 'Jujustu Kaisen', 'Manga', 160, 'jjk1.jpeg'),
(58, 'Tokyo Ghouls', 'Manga', 160, 'tg1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `user_type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `user_type`) VALUES
(1, 'AnyBooks', 'anybooks00@gmail.com', 'f423d2f4a99d2f28afa5d7e54f5e5871', 'admin'),
(2, 'User1', 'user1@gmail.com', '62c72f89650867bd081ce73f5d39c213', 'user'),
(3, 'User2', 'user2@gmail.com', '0df7314c4a7147623d35fcc78e1f98cc', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
