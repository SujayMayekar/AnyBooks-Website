<?php

include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Home</title>


   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   
   <link rel="stylesheet" href="style.css">

</head>
<body>
   
<?php include 'header.php'; ?>

<section class="home">

</section>

<section class="hometext">
<section class="home-text">
   <div class="content">
      <h3>Books At Your Doorstep To Take You Theirs</h3>
      <p> Welcome & get ready to embark on a journey with Books </p>
   </div>
</section>


<section class="about">

   <div class="flex">

      <div class="image">
         <img src="bg1.jpg" alt="">
      </div>

      <div class="content">
         <h3>About Us</h3>
         <p> Welcome to AnyBooks, your literary haven in the Digital realm! Established with a passion for all 'Genres' of books, we are more than just an online bookstore -- we're a gateway to world's of imagination, knowledge, mystery, inspiration & everything that a Book has to offer.</p>
         <a href="aboutus.php" class="btn">Read More</a>
      </div>

   </div>

</section>
</section>

<section class="home-contact">

   <div class="content">
      <h3>Liked our Services</h3>
      <p> At AnyBooks, your reading experience is at the heart of everything we do. Your feedback is a compass that guides us towards continuous improvement. By sharing your thoughts, you contribute to shaping AnyBooks into a better platform for all Readers.</p>
      <a href="feedback.php" class="btn">Review Us</a>
   </div>

</section>

<section class="authors">

   <h1 class="title"> Our Top 3 Best-Sellers </h1>

   <div class="box-container">

      <div class="box">
         <img src="images/bestseller1.jpg" alt="">
         
         <h3> Novel </h3>
      </div>

      <div class="box">
         <img src="images/bestseller2.jpg" alt="">
         
         <h3> Horror </h3>
      </div>

      <div class="box">
         <img src="images/bestseller3.jpg" alt="">
         
         <h3> Psychological </h3>
      </div>
   </div>

</section>

<?php include 'footer.php'; ?>

<script src="script.js"></script>

</body>
</html>