<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Welcome</title>

   <style>
    body, html {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      width: 100%;
      height: 100%;
      overflow: hidden;
      font-family: Arial, sans-serif;
      background-color: black;
    }

    .container {
      position: relative;
      width: 100%;
      height: 100%;
    }

    .image {
      position: absolute;
      width: 100%;
      height: 100%;
      object-fit: cover;
      opacity: 1;
      transition: opacity 2s ease-in-out;
    }

    .text-link {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      opacity: 0;
      text-align: center;
      transition: opacity 2s ease-in-out;
    }

    .text-link a {
      text-decoration: none;
      color: turquoise;
      font-size: 48px;
      font-weight: bold;
    }
  </style>
</head>

<body>

  <div class="container">
    <img src="bg2.jpg" alt="Image" class="image" id="image">
    <div class="text-link" id="textLink">
      <a href="login.php">Welcome to Anybooks !!</a>
    </div>
  </div>

  <script>
    window.onload = function() {
      setTimeout(() => {
        document.getElementById('image').style.opacity = '0';
        document.getElementById('textLink').style.opacity = '1';
      }, 3400); 
    };
  </script>

</body> 
</html>