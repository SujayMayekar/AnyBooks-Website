<section class="footer">

   <div class="box-container">

      <div class="box">
         <style>
            img{
               width: 200px;
            }
         </style>
         <img
            className="Logo"
            src="anybookslogo.png"/>
      </div>

      <div class="box">
         <h3>Jump To</h3>
         <a href="home.php">Home</a>
         <a href="aboutus.php">About</a>
         <a href="books.php">Books</a>
         <a href="feedback.php">FeedBack</a>
      </div>

      <div class="box">
         <h3>Contact Us</h3>
         <p> <i class="fas fa-phone"></i> +91 9876543210 </p>
         <p> <i class="fas fa-phone"></i> +012-345-6789 </p>
         <p> <i class="fas fa-envelope"></i> anybooks00@gmail.com </p>
         <p> <i class="fas fa-map-marker-alt"></i> Mumbai, India - 400***</p>
      </div>

      <div class="box">
         <h3>Follow Us</h3>
         <a href="https://www.facebook.com/"> <i class="fab fa-facebook-f"></i> Facebook </a>
         <a href="https://twitter.com/"> <i class="fab fa-twitter"></i> Twitter </a>
         <a href="https://www.instagram.com/"> <i class="fab fa-instagram"></i> Instagram </a>
         <a href="https://www.youtube.com/"> <i class="fab fa-youtube"></i> YouTube </a>
      </div>

   </div>

</section>