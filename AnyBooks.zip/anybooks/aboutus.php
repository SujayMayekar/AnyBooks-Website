<?php

include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>About</title>

   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <link rel="stylesheet" href="style.css">

</head>
<body>
   
<?php include 'header.php'; ?>

<section class="aboutpage">
   <div class="heading">
      <h3>About Us</h3>
   </div>

   <section class="about">

      <div class="flex">

         <div class="content">
            <h3> When it all Begin </h3>
            <p> Welcome to AnyBooks, where the magic of reading comes to life. Our journey began in 2020, when a group of avid bookworms decided to create an online haven for fellow bibliophiles. We shared a common belief that books have the power to transform lives, spark imagination, and bring people together. </p>
            <p> The idea was simple but powerful: to make the world of literature available to anyone, anywhere. </p>
            <p> An idea sparked to goal when we had a vision of curating a selection of books that would not only cater to various tastes but also inspire a love for reading in people of all ages. From then, we have never looked back. We've shipped books to passionate readers in every corner of the globe, and our commitment to quality, diversity, and outstanding service has remained unwavering. </p>
            <p> We invite you to explore our virtual shelves, discover new worlds, and embark on literary adventures with us. Whether you're a lifelong book lover or just beginning your reading journey, AnyBooks is here to inspire and support you every step of the way. </p>
         </div>

      </div>

   </section>

   <section class="about">

      <div class="flex">

         <div class="image">
            <img src="bg4.jpg" alt="">
         </div>

         <div class="content">
            <h3>why choose us?</h3>
            <p> Discover a world of literature with our bookstore's diverse collection spanning genres & interests. Our knowledgeable staff has & always will give there best to ensure a enjoyable hassle-free online shopping, exceptional customer service & sustainable prices that make us the ideal choice for all book enthusiasts. </p>
            <p> Join us for exclusive author events & explore unique editions as you immerse yourself in our vibrant community </p>
         </div>

      </div>

   </section>
</section>

<section class="reviews">

   <h1 class="title"> 3 Pillars of our Team </h1>

   <div class="box-container">

      <div class="box">
         <img src="images/team1.png" alt="">
         <p> Arthur Leywin </p>
         <h3> CEO </h3>
      </div>

      <div class="box">
         <img src="images/team2.png" alt="">
         <p> Tessia Eralith </p>
         <h3> Marketing Head </h3>
      </div>

      <div class="box">
         <img src="images/team3.png" alt="">
         <p> Sam Urlaw </p>
         <h3> Data Anaylist </h3>
      </div>

   </div>

</section>

<?php include 'footer.php'; ?>

<script src="script.js"></script>

</body>
</html>