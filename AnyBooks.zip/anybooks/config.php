<?php

$conn = mysqli_connect('localhost','root','','anybooks') or die('connection failed');

?>