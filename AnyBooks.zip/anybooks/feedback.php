<?php

include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
}

if(isset($_POST['send'])){

   $name = mysqli_real_escape_string($conn, $_POST['name']);
   $email = mysqli_real_escape_string($conn, $_POST['email']);
   $number = $_POST['number'];
   $msg = mysqli_real_escape_string($conn, $_POST['message']);

   $select_message = mysqli_query($conn, "SELECT * FROM `feedback` WHERE name = '$name' AND email = '$email' AND number = '$number' AND message = '$msg'") or die('query failed');

   if(mysqli_num_rows($select_message) > 0){
      $message[] = 'message sent already!';
   }else{
      mysqli_query($conn, "INSERT INTO `feedback`(user_id, name, email, number, message) VALUES('$user_id', '$name', '$email', '$number', '$msg')") or die('query failed');
      $message[] = 'message sent successfully!';
   }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Feedback</title>

   
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   
   <link rel="stylesheet" href="style.css">
   
</head>
<body>
   
<?php include 'header.php' ?>

<section class="feedbacktitle">
   <div class="titlef">
      <h3>Review Us</h3>
   </div>
</section>

<section class="contact">

   <form action="" method="post">
      <h3>Comment Your Experience</h3>
      <input type="text" name="name" required placeholder="Enter your Username" class="box">
      <input type="email" name="email" required placeholder="Enter your Email" class="box">
      <input type="tel" name="number" required placeholder="Enter your Number" class="box">
      <textarea name="message" class="box" placeholder="Your Review" id="" cols="30" rows="10"></textarea>
      <input type="submit" value="Send" name="send" class="btn">
   </form>

</section>

<section class="reviews">

   <h1 class="title">client reviews</h1>

   <div class="box-container">

      <div class="box">
         <h3> Cid Kagenoh </h3>
         <p> A virtual paradise for book lovers, offering an expansive collection at your fingertips. </p>
      </div>

      <div class="box">
         <h3> Maki Zenin </h3>
         <p> Effortless online shopping paired with prompt deliveries- my go-to for literary indulgence. </p>
      </div>

      <div class="box">
         <h3> Serena </h3>
         <p> From hard-to-find titles to popular bestsellers, an online haven that satisfies all reading cravings. </p>
      </div>

      <div class="box">
         <h3> Ichinose </h3>
         <p> Quick & Hassle-free shopping, this website truly delivers. </p>
      </div>

      <div class="box">
         <h3> Rin Itoshi </h3>
         <p> This website is a reader's dream come true, intuitive and well-organized. </p>
      </div>

      <div class="box">
         <h3> Izumi </h3>
         <p> From bestsellers to new releases that are set to conquer every reader, this website has is all. </p>
      </div>

   </div>

</section>

<?php include 'footer.php'; ?>


<script src="script.js"></script>

</body>
</html>